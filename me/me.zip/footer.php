<?php
	echo '<footer class="box-color">
	<p class="title text-color">Property of Steven Larner</p>
</footer>

<noscript>Your browser does not support JavaScript!</noscript>
</body>
</html>';