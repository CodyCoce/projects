<?php
	include_once("db-login.php");
	
echo '<!DOCTYPE html>
	<html lang="en">
	<head>
	<meta charset="UTF-8">
	<meta name="description" content="This is a template document.">
	<meta name="keywords" content="HTML,CSS,JavaScript,template,document">
	<meta name="author" content="Steven Larner">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<script src="scripts.js"></script>
	<link rel="stylesheet" type="text/css" href="styles.css">
	<script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
	<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
	<title>'.$user.'\'s Profiles</title>
	</head>
	<body class="background-color">';