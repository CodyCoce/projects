<?php
	session_start();
	include_once("db-login.php");
	
	if (empty($_GET)) {
		$user = 'Unknown User';
	}
	else {
		$user = $_GET['user'];
	}
	if (empty($user)) {
		$user = 'Unknown User';
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="description" content="This is a template document.">
<meta name="keywords" content="HTML,CSS,JavaScript,template,document">
<meta name="author" content="Steven Larner">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="scripts.js"></script>
<link rel="stylesheet" type="text/css" href="styles.css">
<script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
<script defer src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
<title><?php echo $user; ?>'s Profiles</title>
</head>
<body class="background-color">

<?php
	include("header.php");
?>

<header class="box-color">
	<p class="title text-color"><?php echo $user; ?>'s Profiles</p>
</header>

<div class="main">
	
	<div class="desktop">
		<?php
			include("index-content.php");
		?>
	</div>
	
	<div class="mobile">
		<?php
			include("index-content-mobile.php");
		?>
	</div>

</div>

<?php
	include("footer.php");
?>