<?php
// Xampp login /**/
/*$servername = "localhost";
$dBUsername = "root";
$dBPassword = "pwdpwd";
$dBName = "user_profiles";*/

// Hostwinds login 
$servername = "localhost";
$dBUsername = "fosqhemv_me";
$dBPassword = "6R1s8EizWxex";
$dBName = "fosqhemv_me";

$conn = mysqli_connect($servername, $dBUsername, $dBPassword, $dBName);

if (!$conn) {
	die("Connection failed: ".mysqli_connect_error());
}